package com.example.springBoot.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springBoot.model.SearchHelpApiModel;
import com.example.springBoot.model.WellCompletionWithDatedModel;

//logic
@RestController
public class MainSearchApiController {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@RequestMapping(value = "/welcompletion/extendedsearch", method = RequestMethod.GET)
	public ResponseEntity<List<WellCompletionWithDatedModel>> getDetails(@RequestParam Map<String, String> params){
		
		if(params.isEmpty()) {
			String wellCompletionWithDatedQuery = "SELECT prd_pr_wc.client, prd_pr_wc.wl_no, prd_pr_wc.wc_de, prd_pr_wc.api_well_no, prd_pr_wc.api_wc_no, "
			+ "prd_pr_wc.wc_type, prd_pr_wc.pri_geo_loc, prd_pr_wc.sec_geo_loc, prd_pr_wc.shl_longitude, prd_pr_wc.shl_latitude, prd_pr_wc.bhl_longitude, "
			+ "prd_pr_wc.bhl_latitude, prd_pr_wc.wc_xref1, prd_pr_wc.wc_xref2, prd_pr_wc_dtd.id, prd_pr_wc_dtd.wc_sts, prd_pr_wc_dtd.comp_cd , prd_pr_wc_dtd.wl_no, prd_pr_wc.wc_no, "
			+ "prd_pr_wc_dtd.eff_fm_dt, prd_pr_wc_dtd.eff_to_dt, prd_pr_wc_dtd.wc_class, prd_pr_wc_dtd.wc_sts, prd_pr_wc_dtd.rep_well_cnt, prd_pr_wc_dtd.op_fl, prd_pr_wc_dtd.operator, prd_pr_wc_dtd.comp_cd, prd_pr_wc_dtd.cost_ctr from prd_pr_wc "
			+ "INNER JOIN prd_pr_wc_dtd ON prd_pr_wc.wl_no=prd_pr_wc_dtd.wl_no";
			List<WellCompletionWithDatedModel> queryResult = jdbcTemplate.query(wellCompletionWithDatedQuery, new BeanPropertyRowMapper(WellCompletionWithDatedModel.class));
			return new ResponseEntity<>(queryResult, HttpStatus.OK);
			
		}else {
			Set<String> keys = params.keySet();
			String queryValues = "";
			String wellCompletionWithDatedQuery = "SELECT prd_pr_wc.client, prd_pr_wc.wl_no, prd_pr_wc.wc_de, prd_pr_wc.api_well_no, prd_pr_wc.api_wc_no, "
					+ "prd_pr_wc.wc_type, prd_pr_wc.pri_geo_loc, prd_pr_wc.sec_geo_loc, prd_pr_wc.shl_longitude, prd_pr_wc.shl_latitude, prd_pr_wc.bhl_longitude, "
					+ "prd_pr_wc.bhl_latitude, prd_pr_wc.wc_xref1, prd_pr_wc.wc_xref2, prd_pr_wc_dtd.id, prd_pr_wc_dtd.wc_sts, prd_pr_wc_dtd.comp_cd , prd_pr_wc_dtd.wl_no, prd_pr_wc.wc_no, "
					+ "prd_pr_wc_dtd.eff_fm_dt, prd_pr_wc_dtd.eff_to_dt, prd_pr_wc_dtd.wc_class, prd_pr_wc_dtd.wc_sts, prd_pr_wc_dtd.rep_well_cnt, prd_pr_wc_dtd.op_fl, prd_pr_wc_dtd.operator, prd_pr_wc_dtd.comp_cd, prd_pr_wc_dtd.cost_ctr from prd_pr_wc "
					+ "INNER JOIN prd_pr_wc_dtd ON prd_pr_wc.wl_no=prd_pr_wc_dtd.wl_no WHERE ";
			String wellCompletionWithDatedQueryWithValues = "";
			for(String key: keys) {
				String keyName = key.toString();
				//if the parameters contain * symbol
				if(params.get(key).contains("*")) {
					String replacedValue = params.get(key).replace("*", "%");
					if(keyName.equalsIgnoreCase("Client") || keyName.equalsIgnoreCase("wl_no") || keyName.equalsIgnoreCase("wc_no")){
						queryValues += ("prd_pr_wc." + key + " LIKE '" + replacedValue + "' AND ");
					}else {
						queryValues += (key + " LIKE '" + replacedValue + "' AND ");
					}
					StringBuffer stringBuffer = new StringBuffer(queryValues);
					stringBuffer.delete(stringBuffer.length() - 4, stringBuffer.length()-0);
					wellCompletionWithDatedQueryWithValues = wellCompletionWithDatedQuery + stringBuffer;
					
				}else {
					if(keyName.equalsIgnoreCase("Client") || keyName.equalsIgnoreCase("wl_no") || keyName.equalsIgnoreCase("wc_no")){
						queryValues += ("prd_pr_wc." + key + " = '" + params.get(key) + "' AND ");
					}else {
						queryValues += (key + " = '" + params.get(key) + "' AND ");
					}
					StringBuffer stringBuffer = new StringBuffer(queryValues);
					stringBuffer.delete(stringBuffer.length() - 4, stringBuffer.length()-0);
					wellCompletionWithDatedQueryWithValues = wellCompletionWithDatedQuery + stringBuffer;
				}
			}
			List<WellCompletionWithDatedModel> queryResult = jdbcTemplate.query(wellCompletionWithDatedQueryWithValues, new BeanPropertyRowMapper(WellCompletionWithDatedModel.class));
			return new ResponseEntity<>(queryResult, HttpStatus.OK);
		}	
	}
	
	@RequestMapping(value = "/welcompletion",
            method = RequestMethod.GET)
	public ResponseEntity<List<SearchHelpApiModel>> getInfo(@RequestParam Map<String, String> params) throws Exception	{
		if(params.isEmpty()) {
			String WellCompletionquery = "SELECT  wl_no, wc_no, wc_de, api_well_no, api_wc_no, wc_type, pri_geo_loc, sec_geo_loc, wc_xref1, wc_xref2 FROM prd_pr_wc";
			List<SearchHelpApiModel> queryResult = jdbcTemplate.query(WellCompletionquery, new BeanPropertyRowMapper(SearchHelpApiModel.class));
			return new ResponseEntity<>(queryResult, HttpStatus.OK);
			
		}else {
			Set<String> keys = params.keySet();
			String queryValues = "";
			String wellCompletionQuery = "SELECT  wl_no, wc_no, wc_de, api_well_no, api_wc_no, wc_type, pri_geo_loc, sec_geo_loc, wc_xref1, wc_xref2 FROM prd_pr_wc WHERE ";
			String WellCompletionQueryWithValues = "";
			for(String key: keys) {
				//String keyName = key.toString();
				//if the parameters contain * symbol
				if(params.get(key).contains("*")) {
					String replacedValue = params.get(key).replace("*", "%");
					queryValues += (key + " LIKE '" + replacedValue + "' AND ");
					StringBuffer stringBuffer = new StringBuffer(queryValues);
					stringBuffer.delete(stringBuffer.length() - 4, stringBuffer.length()-0);
					WellCompletionQueryWithValues = wellCompletionQuery + stringBuffer;
					
				}else {

					queryValues += (key + " = '" + params.get(key) + "' AND ");
				
					StringBuffer stringBuffer = new StringBuffer(queryValues);
					stringBuffer.delete(stringBuffer.length() - 4, stringBuffer.length()-0);
					WellCompletionQueryWithValues = wellCompletionQuery + stringBuffer;
				}
			}
			
			System.out.println(WellCompletionQueryWithValues);
			List<SearchHelpApiModel> queryResult = jdbcTemplate.query(WellCompletionQueryWithValues, new BeanPropertyRowMapper(SearchHelpApiModel.class));
			return new ResponseEntity<>(queryResult, HttpStatus.OK);
		}
	}
}
