package com.example.springBoot.model;

public class WellCompletionWithDatedModel {
	private String Client;
	private String wl_no;
	private String wc_no;
	private String wc_de;
	private String api_well_no;
	private String api_wc_no;
	private String wc_type;
	private String pri_geo_loc;
	private String sec_geo_loc;
	private String shl_longitude;
	private String shl_latitude;
	private String bhl_longitude;
	private String bhl_latitude;
	private String wc_xref1;
	private String wc_xref2;
	private String id;
	private String eff_fm_dt;
	private String eff_to_dt;
	private String wc_class;
	private String wc_sts;
	private String rep_well_cnt;
	private String op_fl;
	private String operator;
	private String comp_cd;
	private String cost_ctr;
	public WellCompletionWithDatedModel() {
		super();
	}
	public WellCompletionWithDatedModel(String client, String wl_no, String wc_no, String wc_de, String api_well_no,
			String api_wc_no, String wc_type, String pri_geo_loc, String sec_geo_loc, String shl_longitude,
			String shl_latitude, String bhl_longitude, String bhl_latitude, String wc_xref1, String wc_xref2, String id,
			String eff_fm_dt, String eff_to_dt, String wc_class, String wc_sts, String rep_well_cnt, String op_fl,
			String operator, String comp_cd, String cost_ctr) {
		super();
		Client = client;
		this.wl_no = wl_no;
		this.wc_no = wc_no;
		this.wc_de = wc_de;
		this.api_well_no = api_well_no;
		this.api_wc_no = api_wc_no;
		this.wc_type = wc_type;
		this.pri_geo_loc = pri_geo_loc;
		this.sec_geo_loc = sec_geo_loc;
		this.shl_longitude = shl_longitude;
		this.shl_latitude = shl_latitude;
		this.bhl_longitude = bhl_longitude;
		this.bhl_latitude = bhl_latitude;
		this.wc_xref1 = wc_xref1;
		this.wc_xref2 = wc_xref2;
		this.id = id;
		this.eff_fm_dt = eff_fm_dt;
		this.eff_to_dt = eff_to_dt;
		this.wc_class = wc_class;
		this.wc_sts = wc_sts;
		this.rep_well_cnt = rep_well_cnt;
		this.op_fl = op_fl;
		this.operator = operator;
		this.comp_cd = comp_cd;
		this.cost_ctr = cost_ctr;
	}
	public String getClient() {
		return Client;
	}
	public void setClient(String client) {
		Client = client;
	}
	public String getWl_no() {
		return wl_no;
	}
	public void setWl_no(String wl_no) {
		this.wl_no = wl_no;
	}
	public String getWc_no() {
		return wc_no;
	}
	public void setWc_no(String wc_no) {
		this.wc_no = wc_no;
	}
	public String getWc_de() {
		return wc_de;
	}
	public void setWc_de(String wc_de) {
		this.wc_de = wc_de;
	}
	public String getApi_well_no() {
		return api_well_no;
	}
	public void setApi_well_no(String api_well_no) {
		this.api_well_no = api_well_no;
	}
	public String getApi_wc_no() {
		return api_wc_no;
	}
	public void setApi_wc_no(String api_wc_no) {
		this.api_wc_no = api_wc_no;
	}
	public String getWc_type() {
		return wc_type;
	}
	public void setWc_type(String wc_type) {
		this.wc_type = wc_type;
	}
	public String getPri_geo_loc() {
		return pri_geo_loc;
	}
	public void setPri_geo_loc(String pri_geo_loc) {
		this.pri_geo_loc = pri_geo_loc;
	}
	public String getSec_geo_loc() {
		return sec_geo_loc;
	}
	public void setSec_geo_loc(String sec_geo_loc) {
		this.sec_geo_loc = sec_geo_loc;
	}
	public String getShl_longitude() {
		return shl_longitude;
	}
	public void setShl_longitude(String shl_longitude) {
		this.shl_longitude = shl_longitude;
	}
	public String getShl_latitude() {
		return shl_latitude;
	}
	public void setShl_latitude(String shl_latitude) {
		this.shl_latitude = shl_latitude;
	}
	public String getBhl_longitude() {
		return bhl_longitude;
	}
	public void setBhl_longitude(String bhl_longitude) {
		this.bhl_longitude = bhl_longitude;
	}
	public String getBhl_latitude() {
		return bhl_latitude;
	}
	public void setBhl_latitude(String bhl_latitude) {
		this.bhl_latitude = bhl_latitude;
	}
	public String getWc_xref1() {
		return wc_xref1;
	}
	public void setWc_xref1(String wc_xref1) {
		this.wc_xref1 = wc_xref1;
	}
	public String getWc_xref2() {
		return wc_xref2;
	}
	public void setWc_xref2(String wc_xref2) {
		this.wc_xref2 = wc_xref2;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEff_fm_dt() {
		return eff_fm_dt;
	}
	public void setEff_fm_dt(String eff_fm_dt) {
		this.eff_fm_dt = eff_fm_dt;
	}
	public String getEff_to_dt() {
		return eff_to_dt;
	}
	public void setEff_to_dt(String eff_to_dt) {
		this.eff_to_dt = eff_to_dt;
	}
	public String getWc_class() {
		return wc_class;
	}
	public void setWc_class(String wc_class) {
		this.wc_class = wc_class;
	}
	public String getWc_sts() {
		return wc_sts;
	}
	public void setWc_sts(String wc_sts) {
		this.wc_sts = wc_sts;
	}
	public String getRep_well_cnt() {
		return rep_well_cnt;
	}
	public void setRep_well_cnt(String rep_well_cnt) {
		this.rep_well_cnt = rep_well_cnt;
	}
	public String getOp_fl() {
		return op_fl;
	}
	public void setOp_fl(String op_fl) {
		this.op_fl = op_fl;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getComp_cd() {
		return comp_cd;
	}
	public void setComp_cd(String comp_cd) {
		this.comp_cd = comp_cd;
	}
	public String getCost_ctr() {
		return cost_ctr;
	}
	public void setCost_ctr(String cost_ctr) {
		this.cost_ctr = cost_ctr;
	}

}
