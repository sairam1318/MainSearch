package com.example.springBoot.model;

public class SearchHelpApiModel {
	private String wl_no;
	private String wc_no;
	private String wc_de;
	private String api_well_no;
	private String api_wc_no;
	private String wc_type;
	private String pri_geo_loc;
	private String sec_geo_loc;
	private String wc_xref1;
	private String wc_xref2;
	
	public SearchHelpApiModel() {
		
	}
	
	public SearchHelpApiModel(String wl_no, String wc_no, String wc_de, String api_well_no, String api_wc_no, String wc_type,
			String pri_geo_loc, String sec_geo_loc, String wc_xref1, String wc_xref2) {
		super();
		this.wl_no = wl_no;
		this.wc_no = wc_no;
		this.wc_de = wc_de;
		this.api_well_no = api_well_no;
		this.api_wc_no = api_wc_no;
		this.wc_type = wc_type;
		this.pri_geo_loc = pri_geo_loc;
		this.sec_geo_loc = sec_geo_loc;
		this.wc_xref1 = wc_xref1;
		this.wc_xref2 = wc_xref2;
	}
	public String getWl_no() {
		return wl_no;
	}
	public void setWl_no(String wl_no) {
		this.wl_no = wl_no;
	}
	public String getWc_no() {
		return wc_no;
	}
	public void setWc_no(String wc_no) {
		this.wc_no = wc_no;
	}
	public String getWc_de() {
		return wc_de;
	}
	public void setWc_de(String wc_de) {
		this.wc_de = wc_de;
	}
	public String getApi_well_no() {
		return api_well_no;
	}
	public void setApi_well_no(String api_well_no) {
		this.api_well_no = api_well_no;
	}
	public String getApi_wc_no() {
		return api_wc_no;
	}
	public void setApi_wc_no(String api_wc_no) {
		this.api_wc_no = api_wc_no;
	}
	public String getWc_type() {
		return wc_type;
	}
	public void setWc_type(String wc_type) {
		this.wc_type = wc_type;
	}
	public String getPri_geo_loc() {
		return pri_geo_loc;
	}
	public void setPri_geo_loc(String pri_geo_loc) {
		this.pri_geo_loc = pri_geo_loc;
	}
	public String getSec_geo_loc() {
		return sec_geo_loc;
	}
	public void setSec_geo_loc(String sec_geo_loc) {
		this.sec_geo_loc = sec_geo_loc;
	}
	public String getWc_xref1() {
		return wc_xref1;
	}
	public void setWc_xref1(String wc_xref1) {
		this.wc_xref1 = wc_xref1;
	}
	public String getWc_xref2() {
		return wc_xref2;
	}
	public void setWc_xref2(String wc_xref2) {
		this.wc_xref2 = wc_xref2;
	}
}
